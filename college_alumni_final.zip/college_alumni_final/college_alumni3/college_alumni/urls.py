from django.contrib import admin
from django.urls import path
from core import views  # Import views from the core app
from django.conf import settings
from django.conf.urls.static import static
from core.views import admin_actions
from core.views import delete_message,view_reports,delete_post



urlpatterns = [
    # Home & Auth
    path('', views.home, name='home'),  
    path('login_signup/', views.login_signup_view, name='login_signup'),  
    path('profile/', views.profile_view, name='profile'),  
    path('logout/', views.logout_view, name='logout'), 
    path('add_bio/', views.add_bio, name='add_bio'), 
     path('feedback/', views.feedback_view, name='feedback_view'),
     path('feedback/', views.feedback, name='feedback'),
    path('delete_post/<int:post_id>/', views.delete_post, name='delete_post'),

    # Admin
    path('admin-login/', views.admin_login, name='admin_login'),  
    path('admin-panel/', views.admin_panel_view, name='admin_panel'),
    path('approve_signup/<int:user_id>/', views.approve_signup, name='approve_signup'),
    path('decline_signup/<int:user_id>/', views.decline_signup, name='decline_signup'),
    path('admin-actions/', admin_actions, name='admin_actions'),  # Admin actions
    path('report_message/', views.report_message, name='report_message'),
    path('reports/', view_reports, name='view_reports'),
    path('delete_reported_content/<int:report_id>/', views.delete_reported_content, name='delete_reported_content'),



    # Query System
    path('query_page/', views.query_page_view, name='query_page'),  
    path('query/<int:query_id>/view_answers/', views.view_answers_view, name='view_answers'),  
    path('query/<int:query_id>/answer/', views.answer_view, name='answer_query'),  
    path('query/<int:query_id>/comment/', views.comment_on_query, name='comment_on_query'),  

    # Search & Reporting
    path('search/', views.search, name='search'),
    path('report_message/', views.report_message, name='report_message'),
    path('report/<str:content_type>/<int:object_id>/', views.report_view, name='report'),  

    # Chat & Posts
    path('chat/', views.chat_view, name='chat'),  
    path('delete_message/<int:message_id>/', delete_message, name='delete_message'),
    path('upload/', views.upload, name='upload'),
    path('post/<int:post_id>/comment/', views.comment_on_post, name='comment_on_post'),
    
    # Job Listings
    path('jobs/', views.job_list, name='job_list'),  # Job list view
    path('job/post/', views.post_job, name='post_job'),  # Post a new job
    path('job/<int:job_id>/', views.job_list, name='job_detail'),  # Job details page
    
    

    # Admin URLs
    path('admin/', admin.site.urls),  # Ensure admin URL is included here
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
