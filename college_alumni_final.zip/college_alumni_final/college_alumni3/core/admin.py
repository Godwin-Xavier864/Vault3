from django.contrib import admin
from .models import User, Post, Query, Answer, Comment, Message, Report, PendingUser

# Check if the User model is already registered to avoid the "AlreadyRegistered" error
try:
    admin.site.unregister(User)  # Unregister the User model if already registered
except admin.sites.AlreadyRegistered:
    pass

# Customizing the User admin to show additional fields in the admin panel
class UserAdmin(admin.ModelAdmin):
    list_display = ('username', 'email', 'is_admin', 'is_student', 'institution', 'department', 'year_of_study')
    list_filter = ('is_admin', 'is_student', 'institution', 'department', 'year_of_study')
    search_fields = ('username', 'email')

admin.site.register(User, UserAdmin)

# Check if the Post model is already registered to avoid the "AlreadyRegistered" error
try:
    admin.site.unregister(Post)  # Unregister the Post model if already registered
except admin.sites.AlreadyRegistered:
    pass

# Registering Post model with the custom admin interface and delete action
class PostAdmin(admin.ModelAdmin):
    list_display = ('user', 'caption', 'created_at')
    list_filter = ('created_at',)
    search_fields = ('caption',)
    
    actions = ['delete_selected_posts']

    def delete_selected_posts(self, request, queryset):
        queryset.delete()

    delete_selected_posts.short_description = 'Delete selected posts'

admin.site.register(Post, PostAdmin)

# Check if the Query model is already registered to avoid the "AlreadyRegistered" error
try:
    admin.site.unregister(Query)  # Unregister the Query model if already registered
except admin.sites.AlreadyRegistered:
    pass

# Registering Query model with the custom admin interface and delete action
class QueryAdmin(admin.ModelAdmin):
    list_display = ('user', 'question', 'created_at')
    list_filter = ('created_at',)
    search_fields = ('question',)
    
    actions = ['delete_selected_queries']

    def delete_selected_queries(self, request, queryset):
        queryset.delete()

    delete_selected_queries.short_description = 'Delete selected queries'

admin.site.register(Query, QueryAdmin)

# Check if the Answer model is already registered to avoid the "AlreadyRegistered" error
try:
    admin.site.unregister(Answer)  # Unregister the Answer model if already registered
except admin.sites.AlreadyRegistered:
    pass

# Registering Answer model with the custom admin interface and delete action
class AnswerAdmin(admin.ModelAdmin):
    list_display = ('query', 'user', 'answer_text', 'created_at')
    list_filter = ('created_at',)
    search_fields = ('answer_text',)
    
    actions = ['delete_selected_answers']

    def delete_selected_answers(self, request, queryset):
        queryset.delete()

    delete_selected_answers.short_description = 'Delete selected answers'

admin.site.register(Answer, AnswerAdmin)

# Registering Comment model with the default admin interface
class CommentAdmin(admin.ModelAdmin):
    list_display = ('user', 'query', 'post', 'text', 'created_at')
    search_fields = ('text',)

admin.site.register(Comment, CommentAdmin)

# Check if the Message model is already registered to avoid the "AlreadyRegistered" error
try:
    admin.site.unregister(Message)  # Unregister the Message model if already registered
except admin.sites.AlreadyRegistered:
    pass

# Registering Message model with the custom admin interface and delete action
class MessageAdmin(admin.ModelAdmin):
    list_display = ('user', 'content', 'timestamp')
    list_filter = ('timestamp',)
    search_fields = ('content',)
    
    actions = ['delete_selected_messages']

    def delete_selected_messages(self, request, queryset):
        queryset.delete()

    delete_selected_messages.short_description = 'Delete selected messages'

admin.site.register(Message, MessageAdmin)

# Check if the Report model is already registered to avoid the "AlreadyRegistered" error
try:
    admin.site.unregister(Report)  # Unregister the Report model if already registered
except admin.sites.AlreadyRegistered:
    pass

# Registering Report model with the default admin interface
# Registering Report model with the default admin interface
class ReportAdmin(admin.ModelAdmin):
    list_display = ('user', 'content_type', 'object_id', 'created_at', 'reason', 'view_reported_content')
    list_filter = ('content_type', 'created_at')
    search_fields = ('reason', 'content_type', 'user__username')

    def view_reported_content(self, obj):
        # Handling different content types
        if obj.content_type == 'message':
            try:
                return Message.objects.get(id=obj.object_id).content
            except Message.DoesNotExist:
                return "Message content not found"
        elif obj.content_type == 'post':
            try:
                return Post.objects.get(id=obj.object_id).caption
            except Post.DoesNotExist:
                return "Post content not found"
        elif obj.content_type == 'query':
            try:
                return Query.objects.get(id=obj.object_id).question
            except Query.DoesNotExist:
                return "Query content not found"
        return "Content Not Found"

    view_reported_content.short_description = 'Reported Content'

admin.site.register(Report, ReportAdmin)
