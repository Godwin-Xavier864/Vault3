from django import forms
from .models import Profile

class ProfilePictureForm(forms.ModelForm):
    class Meta:
        model = Profile
        fields = ['profile_picture']

class ProfileDetailsForm(forms.ModelForm):
    # Make 'job' optional
    job = forms.CharField(max_length=100, required=False, widget=forms.TextInput(attrs={'placeholder': 'Optional'}))

    class Meta:
        model = Profile
        fields = ['institution', 'department', 'year_of_study', 'bio', 'job']
