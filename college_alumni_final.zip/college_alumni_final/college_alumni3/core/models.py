import os
from django.db import models
from django.contrib.auth.models import AbstractUser
from django.contrib.auth import get_user_model



# Custom User Model for Admin and Students
class User(AbstractUser):
    is_admin = models.BooleanField(default=False)
    is_student = models.BooleanField(default=True)

    # Dropdown Choices for Institution, Department, and Year of Study
    INSTITUTION_CHOICES = [
        ('university1', 'University 1'),
        ('university2', 'University 2'),
        # Add more institutions as needed
    ]
    DEPARTMENT_CHOICES = [
        ('cs', 'Computer Science'),
        ('ee', 'Electrical Engineering'),
        # Add more departments as needed
    ]
    YEAR_OF_STUDY_CHOICES = [
        (1, 'First Year'),
        (2, 'Second Year'),
        (3, 'Third Year'),
        (4, 'Fourth Year'),
        # Add more years if needed
    ]

    # Fields for Institution, Department, and Year of Study
    institution = models.CharField(max_length=100, choices=INSTITUTION_CHOICES, null=True, blank=True)
    department = models.CharField(max_length=100, choices=DEPARTMENT_CHOICES, null=True, blank=True)
    year_of_study = models.IntegerField(choices=YEAR_OF_STUDY_CHOICES, null=True, blank=True)

    # Ensure email is unique
    email = models.EmailField(unique=True)  # Make email unique


# Post Model (Images Uploaded by Students)
class Post(models.Model):
    id = models.AutoField(primary_key=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE)  # Each post is linked to a user
    image = models.ImageField(upload_to='posts/')  # Image will be uploaded to 'posts/' directory
    caption = models.TextField()  # Caption for the post
    created_at = models.DateTimeField(auto_now_add=True)  # Timestamp when post was created

    def __str__(self):
        return self.caption  # Display caption in admin panel or shell

# Query Model (Students Posting Questions)
class Query(models.Model):
    id = models.AutoField(primary_key=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    question = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

# Comment Model (For commenting on queries and posts)
class Comment(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    query = models.ForeignKey(Query, on_delete=models.CASCADE, null=True, blank=True)
    post = models.ForeignKey(Post, on_delete=models.CASCADE, null=True, blank=True)
    text = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.text[:50]  # Displaying the first 50 characters of the comment



class Answer(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    query = models.ForeignKey(Query, related_name="answers", on_delete=models.CASCADE)
    answer_text = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)  



# Chat Messages Model
class Message(models.Model):
    id = models.AutoField(primary_key=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    content = models.TextField()
    timestamp = models.DateTimeField(auto_now_add=True)

# Report System
class Report(models.Model):
    id = models.AutoField(primary_key=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    content_type = models.CharField(max_length=50)  # 'post', 'query', 'message'
    object_id = models.IntegerField()
    reason = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)




from django.contrib import admin
from .models import User, Post, Query, Answer, Message, Report

# Customizing the User admin to show is_admin field in admin panel
class UserAdmin(admin.ModelAdmin):
    list_display = ('username', 'email', 'is_admin', 'is_student', 'institution', 'department', 'year_of_study')
    list_filter = ('is_admin', 'is_student', 'institution', 'department', 'year_of_study')
    search_fields = ('username', 'email')

admin.site.register(User, UserAdmin)

# Registering Post model with the default admin interface
class PostAdmin(admin.ModelAdmin):
    list_display = ('user', 'caption', 'created_at')
    list_filter = ('created_at',)
    search_fields = ('caption',)

admin.site.register(Post, PostAdmin)

# Registering Query model with the default admin interface
class QueryAdmin(admin.ModelAdmin):
    list_display = ('user', 'question', 'created_at')
    list_filter = ('created_at',)
    search_fields = ('question',)

admin.site.register(Query, QueryAdmin)

# Registering Answer model with the default admin interface
class AnswerAdmin(admin.ModelAdmin):
    list_display = ('query', 'user', 'answer_text', 'created_at')
    list_filter = ('created_at',)
    search_fields = ('answer_text',)

admin.site.register(Answer, AnswerAdmin)

# Registering Message model with the default admin interface
class MessageAdmin(admin.ModelAdmin):
    list_display = ('user', 'content', 'timestamp')
    list_filter = ('timestamp',)
    search_fields = ('content',)

admin.site.register(Message, MessageAdmin)

# Registering Report model with the default admin interface
class ReportAdmin(admin.ModelAdmin):
    list_display = ('user', 'content_type', 'object_id', 'created_at', 'reason')
    list_filter = ('content_type', 'created_at')
    search_fields = ('reason', 'content_type', 'user__username')

    # This will allow the admin to view the reported content directly in the admin panel
    def view_reported_content(self, obj):
        if obj.content_type == 'message':
            return Message.objects.get(id=obj.object_id).content
        elif obj.content_type == 'post':
            return Post.objects.get(id=obj.object_id).caption
        elif obj.content_type == 'query':
            return Query.objects.get(id=obj.object_id).question
        return "Content Not Found"

    view_reported_content.short_description = 'Reported Content'

admin.site.register(Report, ReportAdmin)

User = get_user_model()
class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    institution = models.CharField(max_length=255, blank=True, null=True)
    department = models.CharField(max_length=255, blank=True, null=True)
    year_of_study = models.CharField(max_length=20, blank=True, null=True)
    profile_picture = models.ImageField(upload_to='profile_pics/', blank=True, null=True)  
    bio = models.TextField(blank=True, null=True)  
    job = models.CharField(max_length=255, blank=True, null=True) 

    def __str__(self):
        return self.user.username

class PendingUser(models.Model):
    username = models.CharField(max_length=255)
    email = models.EmailField()
    password = models.CharField(max_length=255)  # Hashed password
    institution = models.CharField(max_length=255)
    department = models.CharField(max_length=255)
    year_of_study = models.IntegerField()
    is_approved = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.username
    

class ActiveUser(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    institution = models.CharField(max_length=255)
    department = models.CharField(max_length=255)
    year_of_study = models.IntegerField()

    def __str__(self):
        return self.user.username
    

from django.db import models

class JobVacancy(models.Model):
    description = models.TextField()
    job_url = models.URLField(help_text="URL for job application")
    department = models.CharField(max_length=255, help_text="department")

    def __str__(self):
        return f"{self.department} - {self.description[:50]}"  # Show department and snippet in admin panel
    
    
    
    # Feedback Model
class Feedback(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)  # Link feedback to a user
    feedback_text = models.TextField()  # The content of the feedback
    created_at = models.DateTimeField(auto_now_add=True)  # Timestamp when feedback was created

    def __str__(self):
        return f"Feedback by {self.user.username} on {self.created_at.strftime('%Y-%m-%d')}"


    
    
# Settings for Media Files
MEDIA_URL = '/media/'
MEDIA_ROOT = os.path.join(os.path.dirname(__file__), 'media')
