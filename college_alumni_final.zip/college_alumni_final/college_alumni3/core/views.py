from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, authenticate
from django.contrib.auth.decorators import login_required,user_passes_test
from django.contrib.admin.views.decorators import staff_member_required
from django.contrib import messages
from django.contrib.auth.models import User
from .models import Post, Query, Answer, Message, Report,Comment
from django.http import HttpResponse
from django.contrib.auth import logout
from core.models import User
from .models import PendingUser,ActiveUser 
from django.db.models import Q
from .models import JobVacancy
from django.http import JsonResponse
import json
from django.contrib.auth.hashers import make_password
from django.contrib.auth.hashers import make_password
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from .models import Profile
from .forms import ProfilePictureForm, ProfileDetailsForm



# Home Page (Check if the user is authenticated)
def home(request):
    if request.user.is_authenticated:
        # If the user is logged in, show the homepage with posts
        posts = Post.objects.all().order_by('-created_at')  # Order posts by creation date
        return render(request, 'home.html', {'posts': posts})
    else:
        # If not logged in, redirect to the login/signup page
        return redirect('login_signup') 

# Admin Login
def admin_login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)

        if user and user.is_staff:
            login(request, user)
            return redirect('admin_panel')  # Redirect admin to the panel
        else:
            messages.error(request, "Invalid admin credentials.")
    
    return render(request, 'admin_login.html')


# Admin Panel (Restricted to staff users)
def is_admin(user):
    return user.is_staff  # Check if user is admin

@login_required
@user_passes_test(is_admin)
def admin_panel(request):
    return render(request, 'admin_panel.html')


def admin_panel_view(request):
    # Fetch all pending users
    pending_users = PendingUser.objects.filter(is_approved=False)
    return render(request, 'admin_panel.html', {'pending_users': pending_users})

from django.contrib.auth import login

# Admin Approve Signup - Move user to ActiveUser
def approve_signup(request, user_id):
    try:
        # Get the pending user
        pending_user = PendingUser.objects.get(id=user_id)

        # Check if the email already exists
        if User.objects.filter(email=pending_user.email).exists():
            messages.error(request, f"Email {pending_user.email} already exists. Please use a different email.")
            return redirect('admin_panel')  # Redirect to the admin panel if email already exists

        # Create an actual user
        user = User.objects.create_user(
            username=pending_user.username,
            password=pending_user.password,  # create_user handles password hashing
            email=pending_user.email
        )

        # Create an ActiveUser record
        active_user = ActiveUser.objects.create(
            user=user,
            institution=pending_user.institution,
            department=pending_user.department,
            year_of_study=pending_user.year_of_study
        )

        # Delete the pending user
        pending_user.delete()

        # Provide success message
        messages.success(request, f"User {pending_user.username} has been approved and moved to active users.")
        return redirect('admin_panel')  # Redirect to the admin panel after approval

    except PendingUser.DoesNotExist:
        # Handle case when the pending user doesn't exist
        messages.error(request, "Pending user not found.")
        return redirect('admin_panel')




def decline_signup(request, user_id):
    try:
        # Get the pending user and delete them
        pending_user = PendingUser.objects.get(id=user_id)
        pending_user.delete()

        messages.success(request, "User has been declined.")
        return redirect('admin_panel')  # Redirect to the admin panel after decline
    except PendingUser.DoesNotExist:
        messages.error(request, "Pending user not found.")
        return redirect('admin_panel')


# Chat View
@login_required
def chat_view(request):
    messages = Message.objects.all()
    if request.method == 'POST':
        content = request.POST['message']
        message = Message.objects.create(user=request.user, content=content)
        return redirect('chat')  # After sending a message, redirect to the chat view

    return render(request, 'chat.html', {'messages': messages})

@login_required
def delete_message(request, message_id):
    message = get_object_or_404(Message, id=message_id, user=request.user)  # Ensure only the sender can delete
    message.delete()
    return redirect('chat')


# Report Message View
@login_required
def report_message(request):
    if request.method == 'POST':
        try:
            # Parse the JSON data from the request body
            data = json.loads(request.body)

            # Extract fields from the data
            message_id = data.get('message_id')
            username = data.get('username')
            content = data.get('content')

            # Validate the data
            if not message_id or not username or not content:
                return JsonResponse({'status': 'error', 'message': 'Missing required fields'}, status=400)

            # Get the message object and report the message
            message = Message.objects.get(id=message_id)
            user = request.user  # The user reporting the message

            # Create the report entry in the database
            report = Report.objects.create(
                user=user,
                content_type='message',  
                object_id=message.id,
                reason=f"Reported message by {username}: {content}"  
            )

            # Return a success response
            return JsonResponse({'status': 'success', 'message': 'Message reported successfully.'})

        except Message.DoesNotExist:
            return JsonResponse({'status': 'error', 'message': 'Message not found'}, status=404)
        except Exception as e:
            return JsonResponse({'status': 'error', 'message': str(e)}, status=500)

    return JsonResponse({'status': 'error', 'message': 'Invalid request method.'}, status=405)



@staff_member_required
def view_reports(request):
    reports = Report.objects.all().order_by('-created_at')  # Fetch and order reports by creation date
    return render(request, 'view_reports.html', {'reports': reports})


def delete_reported_content(request, report_id):
    # Get the report object
    report = get_object_or_404(Report, id=report_id)

    # Delete the related content based on content_type
    if report.content_type == 'message':
        message = get_object_or_404(Message, id=report.object_id)
        message.delete()
    elif report.content_type == 'post':
        post = get_object_or_404(Post, id=report.object_id)
        post.delete()
    elif report.content_type == 'query':
        query = get_object_or_404(Query, id=report.object_id)
        query.delete()

    # Delete the report itself after deleting the related content
    report.delete()

    # Redirect back to the reported messages page
    return redirect('view_reports')

# Upload Page (Image and Caption Upload)
@login_required
def upload(request):
    if request.method == 'POST':
        if 'image' in request.FILES:
            caption = request.POST['caption']
            image = request.FILES['image']
            print(f"Caption: {caption}")  # Debugging
            print(f"Image: {image}")      # Debugging

            new_post = Post.objects.create(user=request.user, caption=caption, image=image)
            new_post.save()
            return redirect('home')  # Redirect to home page after successful upload
        else:
            print("No image found in the request.")  # Debugging
    return render(request, 'upload.html')



def login_signup_view(request):
    if request.method == 'POST':
        if 'password_confirmation' in request.POST:  # Signup form submission
            username = request.POST['username']
            email = request.POST['email']
            password = request.POST['password']
            password_confirmation = request.POST['password_confirmation']
            institution = request.POST['institution']
            department = request.POST['department']
            year_of_study = request.POST['year_of_study']

            if password != password_confirmation:
                messages.error(request, "Passwords do not match.")
                return redirect('login_signup')

            # Create a PendingUser instance before admin approval
            pending_user = PendingUser.objects.create(
                username=username,
                email=email,
                password=password, 
                institution=institution,
                department=department,
                year_of_study=year_of_study,
                is_approved=False  # Mark as pending
            )

            messages.success(request, "Your signup request has been sent to the admin for approval.")
            return redirect('login_signup')  # Redirect after successful form submission

        elif 'username' in request.POST:  # Login form submission
            username = request.POST['username']
            password = request.POST['password']

            # Authenticate the user (check against User model, not PendingUser)
            user = authenticate(request, username=username, password=password)

            if user is not None and user.is_active:  # If user is authenticated
                login(request, user)
                messages.success(request, f"Welcome, {username}!")
                return redirect('home')  # Redirect to home page after successful login
            else:
                messages.error(request, "Invalid credentials. Please try again.")
                return redirect('login_signup')

    return render(request, 'login_signup.html')  # Return the login/signup page when it's a GET request

@login_required
def profile_view(request):
    # Get or create the user's profile
    profile, created = Profile.objects.get_or_create(user=request.user)

    if request.method == "POST":
        # Handling Profile Picture form submission
        if 'profile_picture' in request.FILES:
            pic_form = ProfilePictureForm(request.POST, request.FILES, instance=profile)
            if pic_form.is_valid():
                pic_form.save()
                return redirect('profile')  # Redirect to retain updated data
        
        # Handling Profile Details form submission (bio, job, department, etc.)
        else:
            details_form = ProfileDetailsForm(request.POST, instance=profile)  # Bind form with profile data
            if details_form.is_valid():
                details_form.save()
                return redirect('profile')  # Redirect to retain updated data

    else:
        pic_form = ProfilePictureForm(instance=profile)  # Initialize Profile Picture form with profile data
        details_form = ProfileDetailsForm(instance=profile)  # Initialize Profile Details form with profile data

    # Get queries and posts related to the user
    queries = request.user.query_set.all()  
    posts = Post.objects.filter(user=request.user)  # Get all posts by the logged-in user

    return render(request, 'profile.html', {
        'profile': profile,
        'pic_form': pic_form,
        'details_form': details_form,
        'queries': queries,
        'posts': posts,  # Pass posts to the template
    })


from .models import Post

def delete_post(request, post_id):
    if request.method == "POST":
        try:
            post = Post.objects.get(id=post_id)
            post.delete()
            return redirect('profile')  # Redirect to profile page after deletion
        except Post.DoesNotExist:
            # handle the case where the post doesn't exist
            return redirect('profile')


# Query Page View (Post and View Queries)
@login_required
def query_page_view(request):
    if request.method == 'POST':
        question = request.POST['question']
        Query.objects.create(user=request.user, question=question)
        return redirect('query_page')
    queries = Query.objects.all()
    return render(request, 'query_page.html', {'queries': queries})

# Answer View (Post Answer to Query)
@login_required
def answer_view(request, query_id):
    query = Query.objects.get(id=query_id)
    if request.method == 'POST':
        answer_text = request.POST['answer']
        Answer.objects.create(query=query, user=request.user, answer_text=answer_text)
        return redirect('query_page')
    return render(request, 'answer_view.html', {'query': query})

# Group Chat View
@login_required
def chat_view(request):
    if request.method == 'POST':
        content = request.POST['message']
        Message.objects.create(user=request.user, content=content)
        return redirect('chat')
    messages = Message.objects.all()
    return render(request, 'chat.html', {'messages': messages})

# Report View (Report Post, Query, or Message)
@login_required
def report_view(request, content_type, object_id):
    if request.method == 'POST':
        reason = request.POST['reason']
        Report.objects.create(user=request.user, content_type=content_type, object_id=object_id, reason=reason)
        return HttpResponse("Report submitted successfully.")
    return render(request, 'report.html', {'content_type': content_type, 'object_id': object_id})

def search(request):
    query = request.GET.get('query', '').strip()  # Get and trim the search query
    department = request.GET.get('department', '').strip()  # Get the selected department 
    year_of_study = request.GET.get('year_of_study', '').strip()  # Get the selected year_of_study 

    users = User.objects.all()

    # Apply filters based on the search query
    if query:
        users = users.filter(
            Q(username__icontains=query) |  # Search by username
            Q(profile__department__icontains=query) |  # Search by department
            Q(profile__year_of_study__icontains=query)  # Search by year_of_study (if it's a string)
        )

    # Apply filter by department if provided
    if department:
        users = users.filter(profile__department__icontains=department)

    # Apply filter by year of study if provided (ensure it's numeric)
    if year_of_study and year_of_study.isdigit():  # Check if year_of_study is a valid number
        users = users.filter(profile__year_of_study=year_of_study)

    return render(request, 'search.html', {'users': users, 'query': query, 'department': department, 'year_of_study': year_of_study})


@login_required
def query_page_view(request):
    queries = Query.objects.all().order_by('-created_at')  # Ensure queries are ordered by creation date

    # Debugging output
    print("Queries fetched:", queries)

    # Check if a search query is present
    search_query = request.GET.get('search', '').strip()
    
    if search_query:
        # Filter queries based on the search term
        queries = queries.filter(Q(question__icontains=search_query))
        print("Filtered Queries:", queries)  

    if request.method == 'POST' and 'question' in request.POST:
        question = request.POST.get('question', '').strip()
        if question:
            Query.objects.create(user=request.user, question=question)
            messages.success(request, "Your query has been posted successfully.")
            return redirect('query_page')  

    return render(request, 'query_page.html', {'queries': queries, 'search_query': search_query})


# View Answers for a Query - Show answers for a specific query
def view_answers_view(request, query_id):
    query = get_object_or_404(Query, id=query_id)
    answers = Answer.objects.filter(query=query).order_by("-created_at")  
    return render(request, "view_answers.html", {"query": query, "answers": answers})




# Answer a Query - Users can post answers to a query
@login_required
def answer_view(request, query_id):
    query = get_object_or_404(Query, id=query_id)

    if request.method == 'POST':
        answer_text = request.POST.get('answer_text', '').strip()
        if answer_text:
            Answer.objects.create(query=query, user=request.user, answer_text=answer_text)
            messages.success(request, "Your answer has been posted successfully.")
        else:
            messages.error(request, "Answer cannot be empty.")
            
        return redirect('view_answers', query_id=query.id)  # Redirect to the view answers page

    return render(request, 'answer_view.html', {'query': query})



# Comment on Post View
@login_required
def comment_on_post(request, post_id):
    post = get_object_or_404(Post, id=post_id)
    
    if request.method == 'POST':
        comment_text = request.POST.get('comment_text', '').strip()
        if comment_text:
            Comment.objects.create(user=request.user, post=post, text=comment_text)
            messages.success(request, "Your comment has been added.")
        else:
            messages.error(request, "Comment cannot be empty.")

    return redirect('view_post', post_id=post.id)



@login_required
def comment_on_query(request, query_id):
    query = get_object_or_404(Query, id=query_id)

    if request.method == 'POST':
        comment_text = request.POST.get('comment_text', '').strip()
        if comment_text:
            
            Comment.objects.create(user=request.user, query=query, text=comment_text)
            messages.success(request, "Your comment has been posted.")
        else:
            messages.error(request, "Comment cannot be empty.")

    return redirect('query_page')  # Redirect back to the query page





@staff_member_required
def admin_actions(request):
    if request.method == 'POST':
        # Handle the deletion of selected items
        action = request.POST.get('action')
        if action == 'delete_posts':
            post_ids = request.POST.getlist('post_ids')
            Post.objects.filter(id__in=post_ids).delete()
            messages.success(request, 'Selected posts deleted successfully.')

        elif action == 'delete_queries':
            query_ids = request.POST.getlist('query_ids')
            Query.objects.filter(id__in=query_ids).delete()
            messages.success(request, 'Selected queries deleted successfully.')

        elif action == 'delete_answers':
            answer_ids = request.POST.getlist('answer_ids')
            Answer.objects.filter(id__in=answer_ids).delete()
            messages.success(request, 'Selected answers deleted successfully.')

        elif action == 'delete_messages':
            message_ids = request.POST.getlist('message_ids')
            Message.objects.filter(id__in=message_ids).delete()
            messages.success(request, 'Selected messages deleted successfully.')

        return redirect('admin_actions')
    
    posts = Post.objects.all()
    queries = Query.objects.all()
    answers = Answer.objects.all()
    all_messages = Message.objects.all()  # Renamed variable to avoid conflict

    return render(request, 'admin_action.html', {
        'posts': posts,
        'queries': queries,
        'answers': answers,
        'messages': all_messages, 
    })



def post_job(request):
    if request.method == "POST":
        description = request.POST['description']
        job_url = request.POST['job_url']
        department = request.POST['department']  # Get department from form input

        JobVacancy.objects.create(description=description, job_url=job_url, department=department)
        return redirect('job_list')  # Redirect to the job list page after submission

    return render(request, 'post_job.html')

def job_list(request):
    jobs = JobVacancy.objects.all()  # Get all job vacancies from the database
    return render(request, 'job_list.html', {'jobs': jobs})  # Pass jobs to the template


def add_bio(request):
    # Fetch the user's profile or create it if it doesn't exist
    profile, created = Profile.objects.get_or_create(user=request.user)

    if request.method == "POST":
        # Handle bio submission
        details_form = ProfileDetailsForm(request.POST, instance=profile)
        if details_form.is_valid():
            details_form.save()
            return redirect('profile')  # Redirect to the profile page after saving
    else:
        details_form = ProfileDetailsForm(instance=profile)

    return render(request, 'add_bio.html', {'details_form': details_form})




from .models import Feedback

@login_required
def feedback_view(request):
    if request.method == 'POST':
        feedback_text = request.POST.get('feedback_text')  # Get feedback text from form

        if feedback_text:
            # Save the new feedback to the database
            Feedback.objects.create(user=request.user, feedback_text=feedback_text)
            messages.success(request, "Your feedback has been submitted successfully!")

            # Redirect to the same page to refresh and show the updated feedback
            return redirect('feedback_view')

    # Retrieve all feedback from the database, including related user and profile data
    feedbacks = Feedback.objects.all().select_related('user').prefetch_related('user__profile')
    feedbacks = Feedback.objects.all().order_by('-created_at')

    return render(request, 'feedback.html', {'feedbacks': feedbacks})



def feedback(request):
    return render(request, 'feedback.html')





# Logout View
def logout_view(request):
    # Perform logout
    logout(request)
    
    messages.info(request, "You have successfully logged out.")

    return redirect('login_signup')  
